package com.callblocker.schedule;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.CallLog;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BlockLog {
    public static class Entry {
        public String number = "";
        public String name = "";
        public long time;
    }

    private static final String PREF = "block_log";
    private static final String KEY = "entries";
    private static final int MAX = 200;

    public static List<Entry> load(Context c) {
        List<Entry> list = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(
                    c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Entry e = new Entry();
                e.number = o.optString("n", "");
                e.name = o.optString("a", "");
                e.time = o.optLong("t", 0);
                list.add(e);
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    private static void save(Context c, List<Entry> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("n", e.number);
                o.put("a", e.name);
                o.put("t", e.time);
                arr.put(o);
            }
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static Entry add(Context c, String number) {
        Entry e = new Entry();
        e.number = number;
        e.time = System.currentTimeMillis();
        for (Rule r : RuleStore.load(c)) {
            if (RuleStore.numbersMatch(r.number, number)
                    && r.name != null && !r.name.trim().isEmpty()) {
                e.name = r.name;
                break;
            }
        }
        List<Entry> list = load(c);
        list.add(0, e);
        while (list.size() > MAX) list.remove(list.size() - 1);
        save(c, list);
        return e;
    }

    public static void clear(Context c) {
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    /** Adds a "Blocked" entry to the phone's own call history. Returns true on success. */
    public static boolean writeSystemLog(Context c, String number) {
        try {
            if (c.checkSelfPermission(Manifest.permission.WRITE_CALL_LOG)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
            ContentValues v = new ContentValues();
            v.put(CallLog.Calls.NUMBER, number);
            v.put(CallLog.Calls.TYPE, CallLog.Calls.BLOCKED_TYPE);
            v.put(CallLog.Calls.DATE, System.currentTimeMillis());
            v.put(CallLog.Calls.DURATION, 0);
            v.put(CallLog.Calls.NEW, 0);
            Uri u = c.getContentResolver().insert(CallLog.Calls.CONTENT_URI, v);
            return u != null;
        } catch (Exception e) {
            return false;
        }
    }
}
