package com.callblocker.schedule;

import android.net.Uri;
import android.telecom.Call;
import android.telecom.CallScreeningService;

public class ScreeningService extends CallScreeningService {

    @Override
    public void onScreenCall(Call.Details details) {
        CallResponse.Builder response = new CallResponse.Builder();
        try {
            if (details.getCallDirection() == Call.Details.DIRECTION_INCOMING) {
                Uri handle = details.getHandle();
                String number = handle != null ? handle.getSchemeSpecificPart() : null;
                if (number != null
                        && RuleStore.shouldBlock(this, number, RuleStore.nowMinutes())) {
                    BlockLog.Entry entry = BlockLog.add(this, number);
                    Notifier.show(this, entry);
                    // If we can write the phone's call history ourselves, do it and tell
                    // the system not to log it again; otherwise let the system log it.
                    boolean logged = BlockLog.writeSystemLog(this, number);
                    response.setDisallowCall(true)
                            .setRejectCall(true)
                            .setSkipNotification(true)
                            .setSkipCallLog(logged);
                }
            }
        } catch (Exception ignored) {
            // On any error, let the call through.
        }
        respondToCall(details, response.build());
    }
}
