package com.callblocker.schedule;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int REQ_ROLE = 1;
    private static final int REQ_CONTACT = 2;
    private static final int REQ_PERM = 3;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final String DASH = " \u2013 ";

    private List<Rule> rules = new ArrayList<>();
    private List<BlockLog.Entry> logs = new ArrayList<>();
    private RuleAdapter ruleAdapter;
    private LogAdapter logAdapter;

    private View statusDot;
    private TextView statusTitle, statusSub, enableBtn, fab, clearBtn;
    private final TextView[] tabText = new TextView[2];
    private final View[] tabInd = new View[2];
    private ListView ruleList, logList;
    private LinearLayout emptyRules, emptyLog, logPane;
    private int tab = 0;

    // editor dialog fields (needed for the contact picker result)
    private EditText dlgName, dlgNumber;

    private int dp(float v) { return Ui.dp(this, v); }

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Ui.BG);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        frame.addView(col, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(24), dp(20), dp(24), dp(12));
        TextView eyebrow = Ui.tv(this, "SCHEDULED PROTECTION", 11, Ui.GOLD, "sans-serif-medium");
        eyebrow.setLetterSpacing(0.2f);
        TextView title = Ui.tv(this, "Call Blocker", 32, Ui.TEXT, "sans-serif-light");
        header.addView(eyebrow);
        header.addView(title);
        col.addView(header, new LinearLayout.LayoutParams(MATCH, WRAP));

        // ---- status card
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.HORIZONTAL);
        statusCard.setGravity(Gravity.CENTER_VERTICAL);
        statusCard.setPadding(dp(16), dp(14), dp(16), dp(14));
        statusCard.setBackground(Ui.box(this, Ui.CARD, 16, Ui.LINE));

        statusDot = new View(this);
        LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotLp.rightMargin = dp(14);
        statusCard.addView(statusDot, dotLp);

        LinearLayout st = new LinearLayout(this);
        st.setOrientation(LinearLayout.VERTICAL);
        statusTitle = Ui.tv(this, "", 16, Ui.TEXT, "sans-serif-medium");
        statusSub = Ui.tv(this, "", 12, Ui.MUTED, "sans-serif");
        st.addView(statusTitle);
        st.addView(statusSub);
        statusCard.addView(st, new LinearLayout.LayoutParams(0, WRAP, 1f));

        enableBtn = Ui.tv(this, "Enable", 13, Ui.BG, "sans-serif-medium");
        enableBtn.setPadding(dp(18), dp(9), dp(18), dp(9));
        enableBtn.setBackground(Ui.box(this, Ui.GOLD, 20));
        enableBtn.setOnClickListener(x -> requestRole());
        statusCard.addView(enableBtn, new LinearLayout.LayoutParams(WRAP, WRAP));

        LinearLayout.LayoutParams scLp = new LinearLayout.LayoutParams(MATCH, WRAP);
        scLp.setMargins(dp(20), dp(4), dp(20), dp(8));
        col.addView(statusCard, scLp);

        // ---- tabs
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(20), dp(8), dp(20), 0);
        tabs.addView(makeTab("Rules", 0), new LinearLayout.LayoutParams(0, WRAP, 1f));
        tabs.addView(makeTab("Blocked history", 1), new LinearLayout.LayoutParams(0, WRAP, 1f));
        col.addView(tabs, new LinearLayout.LayoutParams(MATCH, WRAP));

        // ---- content
        FrameLayout content = new FrameLayout(this);
        col.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));

        ruleAdapter = new RuleAdapter();
        ruleList = newList();
        ruleList.setAdapter(ruleAdapter);
        ruleList.setOnItemClickListener((p, view, pos, id) -> showEditor(rules.get(pos)));
        ruleList.setOnItemLongClickListener((p, view, pos, id) -> {
            final Rule r = rules.get(pos);
            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Delete rule?")
                    .setMessage(r.title())
                    .setPositiveButton("Delete", (d, w) -> {
                        rules.remove(r);
                        RuleStore.save(this, rules);
                        refresh();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
            return true;
        });
        content.addView(ruleList, new FrameLayout.LayoutParams(MATCH, MATCH));

        emptyRules = emptyView("No rules yet",
                "Tap + to block a number, or to allow it only at certain times.");
        content.addView(emptyRules, new FrameLayout.LayoutParams(MATCH, MATCH));

        logAdapter = new LogAdapter();
        logList = newList();
        logList.setAdapter(logAdapter);
        logPane = new LinearLayout(this);
        logPane.setOrientation(LinearLayout.VERTICAL);
        clearBtn = Ui.tv(this, "Clear history", 13, Ui.GOLD, "sans-serif-medium");
        clearBtn.setPadding(dp(24), dp(10), dp(24), dp(4));
        clearBtn.setGravity(Gravity.END);
        clearBtn.setOnClickListener(x ->
                new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Clear blocked history?")
                        .setPositiveButton("Clear", (d, w) -> {
                            BlockLog.clear(this);
                            logs = BlockLog.load(this);
                            refresh();
                        })
                        .setNegativeButton("Cancel", null)
                        .show());
        logPane.addView(clearBtn, new LinearLayout.LayoutParams(MATCH, WRAP));
        logPane.addView(logList, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        content.addView(logPane, new FrameLayout.LayoutParams(MATCH, MATCH));

        emptyLog = emptyView("Nothing blocked yet",
                "Calls this app blocks will be listed here.");
        content.addView(emptyLog, new FrameLayout.LayoutParams(MATCH, MATCH));

        // ---- add button
        fab = Ui.tv(this, "+", 32, Ui.BG, "sans-serif");
        fab.setGravity(Gravity.CENTER);
        fab.setBackground(Ui.oval(Ui.GOLD));
        fab.setElevation(dp(8));
        fab.setOnClickListener(x -> showEditor(null));
        FrameLayout.LayoutParams fabLp = new FrameLayout.LayoutParams(
                dp(60), dp(60), Gravity.BOTTOM | Gravity.END);
        fabLp.setMargins(0, 0, dp(24), dp(28));
        frame.addView(fab, fabLp);

        setContentView(frame);
        setTab(0);

        List<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_CONTACTS);
        }
        if (checkSelfPermission(Manifest.permission.WRITE_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.WRITE_CALL_LOG);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        rules = RuleStore.load(this);
        logs = BlockLog.load(this);
        refresh();
    }

    // ------------------------------------------------------------ UI pieces

    private ListView newList() {
        ListView l = new ListView(this);
        l.setDivider(null);
        l.setDividerHeight(0);
        l.setSelector(new ColorDrawable(Color.TRANSPARENT));
        l.setCacheColorHint(Color.TRANSPARENT);
        l.setClipToPadding(false);
        l.setPadding(0, dp(8), 0, dp(100));
        l.setOverScrollMode(View.OVER_SCROLL_NEVER);
        return l;
    }

    private LinearLayout emptyView(String t, String sub) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(40), dp(40), dp(40), dp(80));
        TextView a = Ui.tv(this, t, 20, Ui.TEXT, "sans-serif-light");
        a.setGravity(Gravity.CENTER);
        TextView b = Ui.tv(this, sub, 14, Ui.MUTED, "sans-serif");
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, dp(8), 0, 0);
        box.addView(a);
        box.addView(b);
        return box;
    }

    private LinearLayout makeTab(String label, final int index) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        TextView tx = Ui.tv(this, label, 14, Ui.MUTED, "sans-serif-medium");
        tx.setGravity(Gravity.CENTER);
        tx.setPadding(0, dp(12), 0, dp(12));
        View ind = new View(this);
        t.addView(tx, new LinearLayout.LayoutParams(MATCH, WRAP));
        t.addView(ind, new LinearLayout.LayoutParams(MATCH, dp(2)));
        t.setOnClickListener(x -> setTab(index));
        tabText[index] = tx;
        tabInd[index] = ind;
        return t;
    }

    private void setTab(int i) {
        tab = i;
        for (int j = 0; j < 2; j++) {
            tabText[j].setTextColor(j == i ? Ui.GOLD : Ui.MUTED);
            tabInd[j].setBackgroundColor(j == i ? Ui.GOLD : Ui.LINE);
        }
        refresh();
    }

    private boolean isRoleHeld() {
        RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        return rm != null && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);
    }

    private void requestRole() {
        RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
        if (rm == null || !rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            Toast.makeText(this, "Call screening is not available on this phone.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), REQ_ROLE);
    }

    private void refresh() {
        if (statusTitle == null) return;
        boolean held = isRoleHeld();
        if (held) {
            statusDot.setBackground(Ui.oval(Ui.GREEN));
            statusTitle.setText("Protection active");
            statusSub.setText("Incoming calls are being screened");
            enableBtn.setVisibility(View.GONE);
        } else {
            statusDot.setBackground(Ui.oval(Ui.RED));
            statusTitle.setText("Protection is off");
            statusSub.setText("Set this app as your Caller ID & spam app");
            enableBtn.setVisibility(View.VISIBLE);
        }

        boolean onRules = tab == 0;
        ruleList.setVisibility(onRules && !rules.isEmpty() ? View.VISIBLE : View.GONE);
        emptyRules.setVisibility(onRules && rules.isEmpty() ? View.VISIBLE : View.GONE);
        fab.setVisibility(onRules ? View.VISIBLE : View.GONE);
        logPane.setVisibility(!onRules && !logs.isEmpty() ? View.VISIBLE : View.GONE);
        emptyLog.setVisibility(!onRules && logs.isEmpty() ? View.VISIBLE : View.GONE);

        ruleAdapter.notifyDataSetChanged();
        logAdapter.notifyDataSetChanged();
    }

    // -------------------------------------------------------------- adapters

    private TextView chip(String text, int color) {
        TextView c = Ui.tv(this, text, 12, color, "sans-serif-medium");
        c.setLetterSpacing(0.05f);
        c.setPadding(dp(10), dp(5), dp(10), dp(5));
        c.setBackground(Ui.box(this, Ui.alpha(color, 0x26), 10));
        return c;
    }

    private LinearLayout cardRow(LinearLayout card) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setPadding(dp(20), dp(6), dp(20), dp(6));
        wrap.addView(card, new LinearLayout.LayoutParams(MATCH, WRAP));
        return wrap;
    }

    private LinearLayout newCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(14), dp(16), dp(14));
        card.setBackground(Ui.box(this, Ui.CARD, 16, Ui.LINE));
        return card;
    }

    private class RuleAdapter extends BaseAdapter {
        @Override public int getCount() { return rules.size(); }
        @Override public Object getItem(int i) { return rules.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final Rule r = rules.get(position);
            LinearLayout card = newCard();

            LinearLayout top = new LinearLayout(MainActivity.this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout texts = new LinearLayout(MainActivity.this);
            texts.setOrientation(LinearLayout.VERTICAL);
            boolean hasName = r.name != null && !r.name.trim().isEmpty();
            texts.addView(Ui.tv(MainActivity.this, hasName ? r.name : r.number,
                    17, Ui.TEXT, "sans-serif-medium"));
            if (hasName) {
                texts.addView(Ui.tv(MainActivity.this, r.number, 13, Ui.MUTED, "sans-serif"));
            }
            top.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));

            final Switch sw = new Switch(MainActivity.this);
            sw.setChecked(r.enabled);
            sw.setFocusable(false);
            Ui.tintSwitch(sw);
            sw.setOnClickListener(x -> {
                r.enabled = sw.isChecked();
                RuleStore.save(MainActivity.this, rules);
                ruleAdapter.notifyDataSetChanged();
            });
            top.addView(sw);
            card.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));

            String time = r.startMin == r.endMin
                    ? "All day"
                    : Rule.fmt(r.startMin) + DASH + Rule.fmt(r.endMin);
            String label = r.mode == Rule.BLOCK ? "BLOCKED" : "ALLOWED ONLY";
            TextView chip = chip(label + "   \u00B7   " + time,
                    r.mode == Rule.BLOCK ? Ui.RED : Ui.GREEN);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(WRAP, WRAP);
            cl.topMargin = dp(12);
            card.addView(chip, cl);

            if (!r.enabled) card.setAlpha(0.5f);
            return cardRow(card);
        }
    }

    private class LogAdapter extends BaseAdapter {
        private final SimpleDateFormat fmt = new SimpleDateFormat("MMM d, h:mm a", Locale.US);

        @Override public int getCount() { return logs.size(); }
        @Override public Object getItem(int i) { return logs.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            BlockLog.Entry e = logs.get(position);
            LinearLayout card = newCard();
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);

            LinearLayout texts = new LinearLayout(MainActivity.this);
            texts.setOrientation(LinearLayout.VERTICAL);
            boolean hasName = e.name != null && !e.name.isEmpty();
            texts.addView(Ui.tv(MainActivity.this, hasName ? e.name : e.number,
                    16, Ui.TEXT, "sans-serif-medium"));
            String sub = (hasName ? e.number + "  \u00B7  " : "") + fmt.format(new Date(e.time));
            texts.addView(Ui.tv(MainActivity.this, sub, 12, Ui.MUTED, "sans-serif"));
            card.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));
            card.addView(chip("BLOCKED", Ui.RED));
            return cardRow(card);
        }
    }

    // ---------------------------------------------------------------- editor

    private TextView label(String t) {
        TextView l = Ui.tv(this, t, 11, Ui.MUTED, "sans-serif-medium");
        l.setLetterSpacing(0.15f);
        l.setPadding(dp(2), dp(16), 0, dp(6));
        return l;
    }

    private EditText field(String hint, String text, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(text);
        e.setInputType(inputType);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(Ui.MUTED);
        e.setPadding(dp(14), dp(13), dp(14), dp(13));
        e.setBackground(Ui.box(this, Ui.FIELD, 12, Ui.LINE));
        return e;
    }

    private void styleSeg(TextView a, TextView b, int mode, TextView desc) {
        boolean block = mode == Rule.BLOCK;
        a.setBackground(block ? Ui.box(this, Ui.GOLD, 9) : new ColorDrawable(Color.TRANSPARENT));
        a.setTextColor(block ? Ui.BG : Ui.MUTED);
        b.setBackground(!block ? Ui.box(this, Ui.GOLD, 9) : new ColorDrawable(Color.TRANSPARENT));
        b.setTextColor(!block ? Ui.BG : Ui.MUTED);
        desc.setText(block
                ? "This number cannot reach you during the selected time."
                : "This number can reach you only during the selected time. Blocked at all other times.");
    }

    private TextView timeBox(LinearLayout row, String cap, int minutes, boolean first) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(10));
        box.setBackground(Ui.box(this, Ui.FIELD, 12, Ui.LINE));
        TextView c = Ui.tv(this, cap, 10, Ui.MUTED, "sans-serif-medium");
        c.setLetterSpacing(0.15f);
        TextView t = Ui.tv(this, Rule.fmt(minutes), 20, Ui.TEXT, "sans-serif-light");
        box.addView(c);
        box.addView(t);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        if (first) lp.rightMargin = dp(8); else lp.leftMargin = dp(8);
        row.addView(box, lp);
        box.setTag(t);
        return t;
    }

    private void showEditor(final Rule existing) {
        final boolean isNew = existing == null;
        final Rule r = isNew ? new Rule() : existing.copy();
        final int[] mode = {r.mode};

        final Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(22), dp(22), dp(22), dp(18));
        box.setBackground(Ui.box(this, Ui.CARD, 24, Ui.LINE));

        box.addView(Ui.tv(this, isNew ? "New rule" : "Edit rule", 24, Ui.TEXT, "sans-serif-light"));

        box.addView(label("NAME (OPTIONAL)"));
        dlgName = field("e.g. Office", r.name,
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        box.addView(dlgName, new LinearLayout.LayoutParams(MATCH, WRAP));

        box.addView(label("PHONE NUMBER"));
        dlgNumber = field("e.g. 01712345678", r.number, InputType.TYPE_CLASS_PHONE);
        box.addView(dlgNumber, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView pick = Ui.tv(this, "Choose from contacts", 14, Ui.GOLD, "sans-serif-medium");
        pick.setPadding(dp(2), dp(12), dp(2), dp(4));
        pick.setOnClickListener(x -> startActivityForResult(
                new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI),
                REQ_CONTACT));
        box.addView(pick);

        box.addView(label("TYPE"));
        LinearLayout seg = new LinearLayout(this);
        seg.setOrientation(LinearLayout.HORIZONTAL);
        seg.setPadding(dp(4), dp(4), dp(4), dp(4));
        seg.setBackground(Ui.box(this, Ui.FIELD, 12, Ui.LINE));
        final TextView segBlock = Ui.tv(this, "Block", 14, Ui.MUTED, "sans-serif-medium");
        final TextView segAllow = Ui.tv(this, "Allow only", 14, Ui.MUTED, "sans-serif-medium");
        segBlock.setGravity(Gravity.CENTER);
        segAllow.setGravity(Gravity.CENTER);
        segBlock.setPadding(0, dp(11), 0, dp(11));
        segAllow.setPadding(0, dp(11), 0, dp(11));
        seg.addView(segBlock, new LinearLayout.LayoutParams(0, WRAP, 1f));
        seg.addView(segAllow, new LinearLayout.LayoutParams(0, WRAP, 1f));
        box.addView(seg, new LinearLayout.LayoutParams(MATCH, WRAP));

        final TextView desc = Ui.tv(this, "", 12, Ui.MUTED, "sans-serif");
        desc.setPadding(dp(2), dp(8), dp(2), 0);
        box.addView(desc);
        styleSeg(segBlock, segAllow, mode[0], desc);
        segBlock.setOnClickListener(x -> { mode[0] = Rule.BLOCK; styleSeg(segBlock, segAllow, mode[0], desc); });
        segAllow.setOnClickListener(x -> { mode[0] = Rule.ALLOW_ONLY; styleSeg(segBlock, segAllow, mode[0], desc); });

        box.addView(label("TIME"));
        LinearLayout times = new LinearLayout(this);
        times.setOrientation(LinearLayout.HORIZONTAL);
        final TextView startT = timeBox(times, "FROM", r.startMin, true);
        final TextView endT = timeBox(times, "TO", r.endMin, false);
        ((View) startT.getParent()).setOnClickListener(x -> pickTime(r.startMin, m -> {
            r.startMin = m;
            startT.setText(Rule.fmt(m));
        }));
        ((View) endT.getParent()).setOnClickListener(x -> pickTime(r.endMin, m -> {
            r.endMin = m;
            endT.setText(Rule.fmt(m));
        }));
        box.addView(times, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView tip = Ui.tv(this, "The range can pass midnight, e.g. 10:00 PM to 5:00 AM.",
                12, Ui.MUTED, "sans-serif");
        tip.setPadding(dp(2), dp(8), dp(2), 0);
        box.addView(tip);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        btns.setPadding(0, dp(22), 0, 0);
        TextView cancel = Ui.tv(this, "Cancel", 15, Ui.MUTED, "sans-serif-medium");
        cancel.setPadding(dp(18), dp(12), dp(18), dp(12));
        cancel.setOnClickListener(x -> d.dismiss());
        TextView save = Ui.tv(this, "Save", 15, Ui.BG, "sans-serif-medium");
        save.setPadding(dp(28), dp(12), dp(28), dp(12));
        save.setBackground(Ui.box(this, Ui.GOLD, 24));
        save.setOnClickListener(x -> {
            String num = dlgNumber.getText().toString().trim();
            if (num.isEmpty()) {
                Toast.makeText(this, "Please enter a phone number.", Toast.LENGTH_SHORT).show();
                return;
            }
            r.number = num;
            r.name = dlgName.getText().toString().trim();
            r.mode = mode[0];
            if (isNew) {
                rules.add(r);
            } else {
                for (int i = 0; i < rules.size(); i++) {
                    if (rules.get(i).id.equals(r.id)) rules.set(i, r);
                }
            }
            RuleStore.save(this, rules);
            refresh();
            d.dismiss();
        });
        btns.addView(cancel);
        btns.addView(save);
        box.addView(btns, new LinearLayout.LayoutParams(MATCH, WRAP));

        ScrollView sv = new ScrollView(this);
        sv.addView(box);
        d.setContentView(sv);
        d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        d.show();
        int w = (int) (getResources().getDisplayMetrics().widthPixels * 0.92f);
        d.getWindow().setLayout(w, WindowManager.LayoutParams.WRAP_CONTENT);
    }

    private interface TimeCallback { void onTime(int minutes); }

    private void pickTime(int current, final TimeCallback cb) {
        new TimePickerDialog(this, android.R.style.Theme_Material_Dialog_Alert,
                (view, h, m) -> cb.onTime(h * 60 + m),
                current / 60, current % 60, false).show(); // false = 12-hour clock
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_ROLE) {
            refresh();
        } else if (requestCode == REQ_CONTACT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try (Cursor c = getContentResolver().query(uri, new String[]{
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    if (dlgNumber != null) dlgNumber.setText(c.getString(0));
                    if (dlgName != null && dlgName.getText().toString().trim().isEmpty()) {
                        dlgName.setText(c.getString(1));
                    }
                }
            } catch (Exception e) {
                Toast.makeText(this, "Could not read contact.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
