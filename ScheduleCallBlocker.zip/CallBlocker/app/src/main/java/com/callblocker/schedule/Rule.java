package com.callblocker.schedule;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;
import java.util.UUID;

public class Rule {
    public static final int BLOCK = 0;       // block the number during the window
    public static final int ALLOW_ONLY = 1;  // allow the number only during the window

    public String id = UUID.randomUUID().toString();
    public String name = "";
    public String number = "";
    public int mode = BLOCK;
    public int startMin = 22 * 60; // 10:00 PM
    public int endMin = 5 * 60;    // 5:00 AM
    public boolean enabled = true;

    public Rule copy() {
        Rule r = new Rule();
        r.id = id;
        r.name = name;
        r.number = number;
        r.mode = mode;
        r.startMin = startMin;
        r.endMin = endMin;
        r.enabled = enabled;
        return r;
    }

    /** Window may wrap past midnight (e.g. 10 PM to 5 AM). Equal start/end = all day. */
    public boolean inWindow(int nowMin) {
        if (startMin == endMin) return true;
        if (startMin < endMin) return nowMin >= startMin && nowMin < endMin;
        return nowMin >= startMin || nowMin < endMin;
    }

    public static String fmt(int minutes) {
        int h = minutes / 60;
        int m = minutes % 60;
        String ap = h >= 12 ? "PM" : "AM";
        int h12 = h % 12;
        if (h12 == 0) h12 = 12;
        return String.format(Locale.US, "%d:%02d %s", h12, m, ap);
    }

    public String summary() {
        String t = fmt(startMin) + " - " + fmt(endMin);
        if (startMin == endMin) t = "All day";
        return mode == BLOCK ? "Blocked: " + t : "Allowed only: " + t;
    }

    public String title() {
        if (name != null && !name.trim().isEmpty()) return name + "  (" + number + ")";
        return number;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("number", number);
        o.put("mode", mode);
        o.put("start", startMin);
        o.put("end", endMin);
        o.put("enabled", enabled);
        return o;
    }

    public static Rule fromJson(JSONObject o) {
        Rule r = new Rule();
        r.id = o.optString("id", r.id);
        r.name = o.optString("name", "");
        r.number = o.optString("number", "");
        r.mode = o.optInt("mode", BLOCK);
        r.startMin = o.optInt("start", r.startMin);
        r.endMin = o.optInt("end", r.endMin);
        r.enabled = o.optBoolean("enabled", true);
        return r;
    }
}
