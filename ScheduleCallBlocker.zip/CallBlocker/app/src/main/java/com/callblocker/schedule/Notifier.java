package com.callblocker.schedule;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

public class Notifier {
    private static final String CHANNEL = "blocked_calls";

    public static void show(Context c, BlockLog.Entry e) {
        try {
            if (e == null) return;
            if (Build.VERSION.SDK_INT >= 33
                    && c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            NotificationManager nm =
                    (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;

            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "Blocked calls", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Shows a notification when a call is blocked");
            nm.createNotificationChannel(ch);

            Intent i = new Intent(c, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(
                    c, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

            String who = (e.name != null && !e.name.isEmpty())
                    ? e.name + " (" + e.number + ")" : e.number;

            Notification n = new Notification.Builder(c, CHANNEL)
                    .setSmallIcon(R.drawable.ic_notif)
                    .setContentTitle("Call blocked")
                    .setContentText(who)
                    .setColor(0xFFD4AF6A)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify((int) (e.time % Integer.MAX_VALUE), n);
        } catch (Exception ignored) {
        }
    }
}
