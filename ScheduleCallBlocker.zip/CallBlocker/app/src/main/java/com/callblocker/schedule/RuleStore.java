package com.callblocker.schedule;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class RuleStore {
    private static final String PREF = "rules_pref";
    private static final String KEY = "rules";

    public static List<Rule> load(Context c) {
        List<Rule> list = new ArrayList<>();
        try {
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                list.add(Rule.fromJson(arr.getJSONObject(i)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static void save(Context c, List<Rule> list) {
        try {
            JSONArray arr = new JSONArray();
            for (Rule r : list) arr.put(r.toJson());
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
                    .edit().putString(KEY, arr.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    private static String digits(String s) {
        StringBuilder sb = new StringBuilder();
        if (s != null) {
            for (char ch : s.toCharArray()) if (Character.isDigit(ch)) sb.append(ch);
        }
        return sb.toString();
    }

    /** Matches numbers regardless of country code / leading zero formatting. */
    public static boolean numbersMatch(String a, String b) {
        String x = digits(a);
        String y = digits(b);
        if (x.isEmpty() || y.isEmpty()) return false;
        if (x.equals(y)) return true;
        int l = Math.min(Math.min(x.length(), y.length()), 10);
        if (l < 7) return false;
        return x.substring(x.length() - l).equals(y.substring(y.length() - l));
    }

    public static int nowMinutes() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    public static boolean shouldBlock(Context c, String incoming, int nowMin) {
        boolean blockHit = false;
        boolean hasAllow = false;
        boolean allowHit = false;
        for (Rule r : load(c)) {
            if (!r.enabled || !numbersMatch(r.number, incoming)) continue;
            if (r.mode == Rule.BLOCK) {
                if (r.inWindow(nowMin)) blockHit = true;
            } else {
                hasAllow = true;
                if (r.inWindow(nowMin)) allowHit = true;
            }
        }
        return blockHit || (hasAllow && !allowHit);
    }
}
