package com.callblocker.schedule;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.Switch;
import android.widget.TextView;

final class Ui {
    static final int BG = 0xFF0E1117;
    static final int CARD = 0xFF171B24;
    static final int FIELD = 0xFF0E1117;
    static final int LINE = 0xFF262C38;
    static final int GOLD = 0xFFD4AF6A;
    static final int TEXT = 0xFFECEFF4;
    static final int MUTED = 0xFF8A93A5;
    static final int RED = 0xFFE5766E;
    static final int GREEN = 0xFF6FCF97;

    private Ui() {}

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable box(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static GradientDrawable box(Context c, int color, float radiusDp, int stroke) {
        GradientDrawable g = box(c, color, radiusDp);
        g.setStroke(dp(c, 1), stroke);
        return g;
    }

    static GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    static TextView tv(Context c, String text, float sp, int color, String family) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setTypeface(Typeface.create(family, Typeface.NORMAL));
        return v;
    }

    static int alpha(int color, int a) {
        return (a << 24) | (color & 0x00FFFFFF);
    }

    static void tintSwitch(Switch sw) {
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{GOLD, 0xFF8A93A5}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{alpha(GOLD, 0x66), 0x33FFFFFF}));
    }
}
