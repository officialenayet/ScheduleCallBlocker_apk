# Schedule Call Blocker — বিল্ড ও ইনস্টল গাইড (বাংলা)

## অ্যাপটি কী করে
- প্রতিটি নাম্বারের জন্য আলাদা রুল সেট করা যায়।
- **Block রুল:** নির্দিষ্ট সময়ের মধ্যে ওই নাম্বার ব্লক থাকবে। (যেমন: রাত ১০:০০ PM – সকাল ৫:০০ AM)
- **Allow only রুল (হোয়াইট লিস্ট):** ওই নাম্বার শুধু নির্দিষ্ট সময়ে কল দিতে পারবে, বাকি সময় ব্লক। (যেমন: ৩:০০ PM – ৫:০০ PM)
- অ্যাপের ভাষা ইংলিশ, সময় ১২ ঘণ্টা (AM/PM) ফরম্যাটে।
- রুল অফ/অন করার সুইচ আছে, ট্যাপ করলে এডিট, লং প্রেস করলে ডিলিট।

## দরকার
- GitHub অ্যাকাউন্ট
- Android 10 বা তার উপরের ফোন

## ধাপ ১: GitHub এ নতুন রিপো বানান
1. GitHub এ **New repository** চাপুন, নাম দিন `ScheduleCallBlocker`, **Create repository**।

## ধাপ ২: ফাইল আপলোড
### কম্পিউটার থেকে (সহজ)
1. জিপ ফাইল এক্সট্রাক্ট করুন।
2. রিপোতে **Add file → Upload files** চাপুন, এক্সট্রাক্ট করা ফোল্ডারের **ভেতরের সব ফাইল ও ফোল্ডার** (`.github` ফোল্ডারসহ) টেনে দিন, **Commit changes**।

### মোবাইল থেকে
মোবাইলে `.github` লুকানো ফোল্ডার আপলোড করা কঠিন, তাই **Add file → Create new file** দিয়ে একটা একটা করে বানান। ফাইলের নামের ঘরে স্ল্যাশ `/` দিলে ফোল্ডার নিজে তৈরি হয়। নিচের প্রতিটি পাথ নামের ঘরে লিখে, কোড পেস্ট করে Commit করুন:

- `.github/workflows/build.yml`
- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/res/values/colors.xml`
- `app/src/main/res/drawable/ic_fg.xml`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml`
- `app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml`
- `app/src/main/java/com/callblocker/schedule/MainActivity.java`
- `app/src/main/java/com/callblocker/schedule/Rule.java`
- `app/src/main/java/com/callblocker/schedule/RuleStore.java`
- `app/src/main/java/com/callblocker/schedule/BlockLog.java`
- `app/src/main/java/com/callblocker/schedule/Ui.java`
- `app/src/main/java/com/callblocker/schedule/ScreeningService.java`

## ধাপ ৩: APK বিল্ড
1. রিপোর **Actions** ট্যাবে যান। কমিট করার পর বিল্ড নিজে শুরু হবে (না হলে **Build APK → Run workflow**)।
2. ৩–৫ মিনিট পর সবুজ টিক ✅ আসলে ওই রানে ক্লিক করুন।
3. একদম নিচে **Artifacts** এ `ScheduleCallBlocker-APK` ডাউনলোড করুন (জিপ আসবে, এক্সট্রাক্ট করলে `app-debug.apk`)।

বিল্ড ফেইল (লাল ❌) করলে রানে ক্লিক করে এরর লগ কপি করে আমাকে পাঠান।

## ধাপ ৪: ইনস্টল ও চালু করা
1. APK ইনস্টল করুন (Unknown sources অনুমতি দিতে হতে পারে)।
2. অ্যাপ খুলে **Enable call blocking** চাপুন।
3. ফোন জিজ্ঞেস করবে "Caller ID & spam app" হিসেবে সেট করবে কিনা — **Schedule Call Blocker** সিলেক্ট করুন। (এটা না করলে অ্যাপ কল ব্লক করতে পারবে না)
4. স্ট্যাটাস সবুজ **ACTIVE** দেখালে **+ Add number rule** চেপে রুল বানান।

## পারমিশন
অ্যাপ প্রথমবার খুললে দুটো পারমিশন চাইবে, দুটোতেই **Allow** দিন:
- **Contacts:** সেভ করা নাম্বার ব্লক করার জন্য।
- **Call logs:** ব্লক করা কল ফোনের নেটিভ ডায়ালারের হিস্ট্রিতে "Blocked" হিসেবে দেখানোর জন্য।

পারমিশন অপশন ধূসর (disabled) থাকলে: ফোনের Settings → Apps → Schedule Call Blocker → উপরের ৩ ডটে **Allow restricted settings** চালু করে আবার পারমিশন দিন।

ব্লক করা কল অ্যাপের ভেতরে **Blocked history** ট্যাবেও দেখা যায়।

## জেনে রাখুন
- ব্লক করা কলে আপনার ফোন রিং করবে না, কলারের কাছে কল কেটে যাবে।
- ফোনের সময় (ঘড়ি) অনুযায়ী শিডিউল চলে।
- নাম্বার `017...` বা `+88017...` যেকোনো ফরম্যাটে দিলে মিলে যাবে।
- একই নাম্বারে একাধিক রুল দেওয়া যায়।
- এই ডিফল্ট কল-ডায়ালার/স্ক্রিনিং অ্যাপ হিসেবে অন্য ক্যালার-আইডি অ্যাপ (যেমন Truecaller) থাকলে একটা সময়ে একটাই সক্রিয় থাকতে পারে।
